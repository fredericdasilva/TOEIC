<?php
include("fonctions.php");

// On appelle la session
session_start();

$i=1; //Compteur de question

//Recuperation des parametres
$nbParam = "";
$reponses = array(array()) ;
$cpt = 1;
$cptQues = 1;
$cptRep = 1;
$index = 0;
$reponses[0][0] = "";
if (isset($_POST['nbParam'])){
	$nbParam = $_POST['nbParam'];
	while($cpt <= $nbParam){
		$cptQues;
		if(isset($_POST['Q$cptQues'])){
			echo $cptQues;
			echo $cptRep;
			//reponses[$cptQues][$cptRep] = ".$_POST['Q$cptQues'].";
			
			if(isset($_POST['R$cptRep'])){
			echo $cptQues;
			echo $cptRep;
				//reponses[$cptQues][$cptRep] = $_POST['R$cptRep'];
				
			}	
		}
		$cptQues++;
		$cptRep++;
		$cpt++;
	}
	//for($titi = 0; $titi <= $cptQues; $titi++){
     	//	for($toto = 0; $toto <= $cptRep; $toto++) {
        //  		echo $reponses[$cptQues][$cptRep] ."<br>";
     	//	} 
	//}
}
//requetes
//liste menu
$res = requete("SELECT * FROM type_exo");
//Insertion des reponses en base
//$res1 = requete("INSERT INTO `feuille_reponse` VALUES ('--ID_USER--', '--ID_EXO--', '--ID_QUESTION--', '--REP--', getdate())");

?>

<html>
<head>
<title>TOEIC</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="forAll.css" rel="stylesheet" type="text/css">

<?php
	if (empty($_SESSION['login_user'])) { ?>
		<div class="titreErreur">Erreur de session, vous allez �tre redirig� automatiquement</div>
		<meta http-equiv="refresh" content="2; url=index.php"/>
<?php } else { 
		 ?>

</head>

<?php //r�cup�ration des param�tres

?>

<body background="images/bg.gif" link="#003399" vlink="#0044D2" alink="#FF3300" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="760" height="100%" border="0" cellpadding="0" cellspacing="0">
  <tr> 
    <td height="70" background="images/top_bg.gif" valign="middle"><table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="50%"><STRONG>ENTRAINEMENT AU TOEIC<STRONG></td>
          <td width="50%" align="right">&nbsp;</td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td height="22" background="images/menu_bg.gif" class="forTexts"><div align="right">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
           
            <td class="forTexts" align="center">|&nbsp;&nbsp;&nbsp;&nbsp;Utiliisateur authentifi� : <?php echo $_SESSION['login_user']; ?>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<a href="deconnexion.php">D�connexion</a> &nbsp;&nbsp;&nbsp;&nbsp;|</td>
          </tr>
        </table>
      </div></td>
  </tr>
  <tr> 
    <td valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="2">
        <tr> 
          <td width="170" valign="top"> 
            <table width="100%" border="0" cellspacing="1" cellpadding="1">
              <tr> 
                <td bgcolor="#4F7DB0" class="forTexts">&nbsp;</td>
                <td bgcolor="#D9E3EE" class="forTexts">&nbsp;<a href="accueil.php">Accueil</a></td>
              </tr>
              <tr> 
                <td bgcolor="#4F7DB0" class="titreMenu" colspan="2">&nbsp;Types d'exercice</td>
              </tr>
		<?php
		//affichage du menu
		while($val=mysql_fetch_array($res)) {
   		echo "<tr><td bgcolor=\"#4F7DB0\" class=\"forTexts\">&nbsp;</td>
                <td bgcolor=\"#D9E3EE\" class=\"forTexts\">&nbsp;<a href=\"typeExo.php?id=".$val["id_type_exo"]."\">".$val["nom_type_exo"]."</a></td></tr>";
		}?>
	      <tr><td bgcolor="#4F7DB0" class="titreMenu" colspan="2">&nbsp;</td></tr>
              <tr>
                <td bgcolor="#4F7DB0" class="forTexts">&nbsp;</td>
                <td bgcolor="#D9E3EE" class="forTexts">&nbsp;<a href="monCompte.php">Mon compte</a></td>
              </tr>
            </table>
            <br>
          </td>
          <td valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="5">
              <tr> 
                <td class="forTexts"><p class="forText"><strong>Liste des exercices disponibles :</strong><br></p>
                  <hr>
                  <p class="forText">
		  <table width="100%" border="0" cellspacing="10" cellpadding="0">
			
		  </table>
                </p>
                </td>
              </tr>
              <tr> 
                <td class="forTexts"></td>
              </tr>
              
            </table></td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td height="40" background="images/bottom_bg.gif" class="forTexts">
<div align="center">All 
        Rights Reserved. 2007. Design by Fridou&Castor Inc</div></td>
  </tr>
</table>
<?php } ?>
</body>
</html>
